import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-information',
  templateUrl: './e-information.component.html',
  styleUrls: ['./e-information.component.css']
})
export class EInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
